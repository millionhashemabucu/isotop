$(document).ready(function(){

    var $grid =  $('.items').isotope({
        itemSelector: '.item',
        percentPosition: true,
        masonry: {
          // use outer width of grid-sizer for columnWidth
          columnWidth: 1
        }
      })
      $('.menu').on( 'click', 'li', function() {
        var filterValue = $(this).attr('data-filter');
        $grid.isotope({ filter: filterValue });
      });
      // active button
      $('.max-width').on('click','li',function(){
          $('li').removeClass('active')
          $(this).addClass('active')
      })
})